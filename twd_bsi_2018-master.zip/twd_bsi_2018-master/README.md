# twd_bsi_2018
Tango With Django do BSI 6 de 2018

# modificar o .gitignore
# clonar o repositorio
# criar o projeto
