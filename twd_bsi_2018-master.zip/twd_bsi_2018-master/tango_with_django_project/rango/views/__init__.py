from .index import index
from .about import about
from .show_category import show_category
from .add_category import Add_Category
# from .add_page import add_page
from .add_page import Add_Page
